import React, { createContext, useContext, useState, useCallback } from 'react';
import type { EQBand, Track, DrumPad, AppSettings, FXModule } from '@/types';

const defaultEQBands: EQBand[] = [
  { frequency: 20, gain: 0, label: '20' },
  { frequency: 25, gain: 0, label: '25' },
  { frequency: 31.5, gain: 0, label: '31.5' },
  { frequency: 40, gain: 0, label: '40' },
  { frequency: 50, gain: 0, label: '50' },
  { frequency: 63, gain: 0, label: '63' },
  { frequency: 80, gain: 0, label: '80' },
  { frequency: 100, gain: 0, label: '100' },
  { frequency: 125, gain: 0, label: '125' },
  { frequency: 160, gain: 0, label: '160' },
  { frequency: 200, gain: 0, label: '200' },
  { frequency: 250, gain: 0, label: '250' },
  { frequency: 315, gain: 0, label: '315' },
  { frequency: 400, gain: 0, label: '400' },
  { frequency: 500, gain: 0, label: '500' },
  { frequency: 630, gain: 0, label: '630' },
  { frequency: 800, gain: 0, label: '800' },
  { frequency: 1000, gain: 0, label: '1k' },
  { frequency: 1300, gain: 0, label: '1.3k' },
  { frequency: 1600, gain: 0, label: '1.6k' },
  { frequency: 2000, gain: 0, label: '2k' },
  { frequency: 2500, gain: 0, label: '2.5k' },
  { frequency: 3100, gain: 0, label: '3.1k' },
  { frequency: 4000, gain: 0, label: '4k' },
];

const defaultTracks: Track[] = Array.from({ length: 9 }, (_, i) => ({
  id: i + 1,
  name: `Track ${i + 1}`,
  instrument: i === 0 ? 'CFX' : i === 1 ? 'FM EP' : i === 2 ? 'PAD' : i === 3 ? 'CELLO DUO' : i === 4 ? 'ALL 9 BARS' : 'EMPTY',
  volume: i < 5 ? -6 : 0,
  pan: 0,
  muted: false,
  solo: false,
  fx: [],
}));

const defaultDrumPads: DrumPad[] = [
  { id: 1, name: 'LOW C', sound: 'kick', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 2, name: 'KICK A', sound: 'kick', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 3, name: 'SNAP B', sound: 'snare', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 4, name: 'CLAP F', sound: 'clap', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 5, name: 'CHIMES', sound: 'chimes', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 6, name: 'KICK C', sound: 'kick', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 7, name: 'SNAP A', sound: 'snare', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 8, name: 'CLAP C', sound: 'clap', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 9, name: 'CLAP A', sound: 'clap', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 10, name: 'LOW A', sound: 'low', velocity: 100, volume: 80, color: '#06b6d4' },
  { id: 11, name: 'CLAP B', sound: 'clap', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 12, name: 'CLAP C', sound: 'clap', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 13, name: 'LOW B', sound: 'low', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 14, name: 'CHIMES B', sound: 'chimes', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 15, name: 'SNARE', sound: 'snare', velocity: 100, volume: 80, color: '#3b82f6' },
  { id: 16, name: 'HIHAT', sound: 'hihat', velocity: 100, volume: 80, color: '#3b82f6' },
];

const defaultSettings: AppSettings = {
  sampleRate: 48000,
  bufferSize: 384,
  polyphony: 400,
  masterTune: 0,
  latency: '8.00 ms',
  velocityCurve: 'Linear',
  interpolationQuality: 'Mid',
  lineOut: false,
  masterLimiter: false,
  invertPedal: false,
  hideMaster: false,
  monoOutput: false,
};

interface AppContextType {
  currentScreen: string;
  setCurrentScreen: (screen: string) => void;
  eqBands: EQBand[];
  setEqBands: (bands: EQBand[]) => void;
  updateEQBand: (index: number, gain: number) => void;
  tracks: Track[];
  setTracks: (tracks: Track[]) => void;
  updateTrackVolume: (trackId: number, volume: number) => void;
  updateTrackPan: (trackId: number, pan: number) => void;
  toggleTrackMute: (trackId: number) => void;
  toggleTrackSolo: (trackId: number) => void;
  drumPads: DrumPad[];
  setDrumPads: (pads: DrumPad[]) => void;
  updateDrumPad: (id: number, updates: Partial<DrumPad>) => void;
  settings: AppSettings;
  setSettings: (settings: AppSettings) => void;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  selectedTrack: number;
  setSelectedTrack: (track: number) => void;
  fxModules: FXModule[];
  setFxModules: (modules: FXModule[]) => void;
  toggleFXModule: (id: string) => void;
  updateFXParam: (moduleId: string, param: string, value: number) => void;
  powerOn: boolean;
  setPowerOn: (on: boolean) => void;
  selectedChannel: 'LEFT' | 'RIGHT' | 'LINK';
  setSelectedChannel: (channel: 'LEFT' | 'RIGHT' | 'LINK') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentScreen, setCurrentScreen] = useState('mixer');
  const [eqBands, setEqBands] = useState<EQBand[]>(defaultEQBands);
  const [tracks, setTracks] = useState<Track[]>(defaultTracks);
  const [drumPads, setDrumPads] = useState<DrumPad[]>(defaultDrumPads);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [selectedTrack, setSelectedTrack] = useState(1);
  const [powerOn, setPowerOn] = useState(true);
  const [selectedChannel, setSelectedChannel] = useState<'LEFT' | 'RIGHT' | 'LINK'>('RIGHT');
  
  const [fxModules, setFxModules] = useState<FXModule[]>([
    {
      id: 'tremolo',
      name: 'Tremolo',
      enabled: true,
      params: { FRQ: 64, FADE: 6, PHS: 0, JNT: 64 },
    },
    {
      id: 'delay',
      name: 'D-DELAY',
      enabled: false,
      params: { time: 64, feedback: 30, mix: 50 },
    },
    {
      id: 'reverb',
      name: 'SPACE',
      enabled: false,
      params: { decay: 50, tone: 64, size: 70, mix: 30 },
    },
    {
      id: 'compressor',
      name: 'VCA-COMP',
      enabled: false,
      params: { THR: -3, RAT: 2.0, ATT: 3, REL: 65, KNE: 32, MIX: 127, GAN: 12.1 },
    },
    {
      id: 'warmth',
      name: 'Warmth',
      enabled: false,
      params: { DRV: 56, TON: 72, LVL: 68 },
    },
  ]);

  const updateEQBand = useCallback((index: number, gain: number) => {
    setEqBands(prev => {
      const newBands = [...prev];
      newBands[index] = { ...newBands[index], gain };
      return newBands;
    });
  }, []);

  const updateTrackVolume = useCallback((trackId: number, volume: number) => {
    setTracks(prev => prev.map(track => 
      track.id === trackId ? { ...track, volume } : track
    ));
  }, []);

  const updateTrackPan = useCallback((trackId: number, pan: number) => {
    setTracks(prev => prev.map(track => 
      track.id === trackId ? { ...track, pan } : track
    ));
  }, []);

  const toggleTrackMute = useCallback((trackId: number) => {
    setTracks(prev => prev.map(track => 
      track.id === trackId ? { ...track, muted: !track.muted } : track
    ));
  }, []);

  const toggleTrackSolo = useCallback((trackId: number) => {
    setTracks(prev => prev.map(track => 
      track.id === trackId ? { ...track, solo: !track.solo } : track
    ));
  }, []);

  const updateDrumPad = useCallback((id: number, updates: Partial<DrumPad>) => {
    setDrumPads(prev => prev.map(pad => 
      pad.id === id ? { ...pad, ...updates } : pad
    ));
  }, []);

  const updateSetting = useCallback(<K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  }, []);

  const toggleFXModule = useCallback((id: string) => {
    setFxModules(prev => prev.map(module => 
      module.id === id ? { ...module, enabled: !module.enabled } : module
    ));
  }, []);

  const updateFXParam = useCallback((moduleId: string, param: string, value: number) => {
    setFxModules(prev => prev.map(module => 
      module.id === moduleId 
        ? { ...module, params: { ...module.params, [param]: value } }
        : module
    ));
  }, []);

  return (
    <AppContext.Provider value={{
      currentScreen,
      setCurrentScreen,
      eqBands,
      setEqBands,
      updateEQBand,
      tracks,
      setTracks,
      updateTrackVolume,
      updateTrackPan,
      toggleTrackMute,
      toggleTrackSolo,
      drumPads,
      setDrumPads,
      updateDrumPad,
      settings,
      setSettings,
      updateSetting,
      selectedTrack,
      setSelectedTrack,
      fxModules,
      setFxModules,
      toggleFXModule,
      updateFXParam,
      powerOn,
      setPowerOn,
      selectedChannel,
      setSelectedChannel,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
