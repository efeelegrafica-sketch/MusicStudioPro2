import React, { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { Download, Check, ChevronLeft, Music, Piano, Guitar, Wind, Speaker } from 'lucide-react';

interface SoundfontCategory {
  id: string;
  name: string;
  icon: React.ElementType;
  count: number;
  sounds: string[];
}

const categories: SoundfontCategory[] = [
  { id: 'piano', name: 'Piano', icon: Piano, count: 8, sounds: ['Royal Grand 3D', 'CFX', 'Full Concert Montage', '80s Layer', 'Ballad Key', 'CP80 Layer', 'S700', 'Felt Piano'] },
  { id: 'keyboard', name: 'Keyboard', icon: Music, count: 16, sounds: ['Comic EP', 'Cristal Rhodes JD800', 'Crystal Rhodes', 'DX 2', 'DX FM EP', 'DX legend'] },
  { id: 'rhodes', name: 'Rhodes', icon: Music, count: 5, sounds: ['Stage 73', 'MKI', 'MKII', 'Wurlitzer', 'Clavinet'] },
  { id: 'organ', name: 'Organ', icon: Speaker, count: 30, sounds: ['B3', 'C3', 'Farfisa', 'Vox Continental', 'Pipe Organ'] },
  { id: 'strings', name: 'Strings', icon: Music, count: 18, sounds: ['Violin', 'Viola', 'Cello', 'Double Bass', 'String Ensemble'] },
  { id: 'brass', name: 'Brass', icon: Music, count: 16, sounds: ['Trumpet', 'Trombone', 'French Horn', 'Tuba', 'Brass Section'] },
  { id: 'woodwind', name: 'Woodwind', icon: Wind, count: 7, sounds: ['Flute', 'Clarinet', 'Oboe', 'Bassoon', 'Saxophone'] },
  { id: 'guitar', name: 'Guitar', icon: Guitar, count: 6, sounds: ['Nylon Guitar', 'Steel Guitar', 'Electric Guitar', 'Bass Guitar', 'Acoustic Bass'] },
  { id: 'bass', name: 'Bass', icon: Music, count: 4, sounds: ['Finger Bass', 'Pick Bass', 'Slap Bass', 'Synth Bass'] },
  { id: 'pad', name: 'Pad', icon: Music, count: 14, sounds: ['Warm Pad', 'Bright Pad', 'Synth Pad', 'Atmosphere', 'Space Pad'] },
  { id: 'choir', name: 'Choir', icon: Music, count: 1, sounds: ['Choir Aahs', 'Choir Oohs', 'Synth Voice'] },
  { id: 'drum', name: 'Drum', icon: Music, count: 4, sounds: ['Standard Kit', 'Room Kit', 'Power Kit', 'Electronic Kit'] },
  { id: 'perc', name: 'Perc', icon: Music, count: 0, sounds: [] },
  { id: 'synth', name: 'Synth', icon: Music, count: 13, sounds: ['Lead', 'Bass', 'Pad', 'FX', 'Arpeggio'] },
  { id: 'sanfona', name: 'Sanfona', icon: Music, count: 15, sounds: ['Sanfona 1', 'Sanfona 2', 'Sanfona 3'] },
  { id: 'drumpad', name: 'Drum Pad', icon: Music, count: 53, sounds: ['Kick', 'Snare', 'Hi-Hat', 'Tom', 'Cymbal'] },
];

export function SoundfontLibrary() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [downloadedSounds, setDownloadedSounds] = useState<Set<string>>(new Set(['CFX', 'Royal Grand 3D', 'DX 2']));
  const { setCurrentScreen } = useApp();

  const toggleDownload = (sound: string) => {
    setDownloadedSounds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sound)) {
        newSet.delete(sound);
      } else {
        newSet.add(sound);
      }
      return newSet;
    });
  };

  const downloadAll = () => {
    if (selectedCategory) {
      const category = categories.find(c => c.id === selectedCategory);
      if (category) {
        setDownloadedSounds(prev => {
          const newSet = new Set(prev);
          category.sounds.forEach(sound => newSet.add(sound));
          return newSet;
        });
      }
    }
  };

  if (selectedCategory) {
    const category = categories.find(c => c.id === selectedCategory);
    if (!category) return null;

    const Icon = category.icon;

    return (
      <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <Icon size={24} className="text-white" />
            <div>
              <span className="text-white font-semibold block">{category.name}</span>
              <span className="text-slate-400 text-sm">{category.sounds.length} soundfonts</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={downloadAll}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
            >
              <Download size={16} />
              Download All
            </button>
            <button 
              onClick={() => setSelectedCategory(null)}
              className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors"
            >
              <ChevronLeft size={18} className="text-slate-400" />
            </button>
          </div>
        </div>

        {/* Sound List */}
        <div className="flex-1 overflow-y-auto">
          {category.sounds.map((sound) => (
            <div 
              key={sound}
              className="flex items-center justify-between px-4 py-3 border-b border-slate-800 hover:bg-slate-800/50 transition-colors"
            >
              <span className="text-slate-300">{sound}</span>
              <button
                onClick={() => toggleDownload(sound)}
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                  downloadedSounds.has(sound)
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                }`}
              >
                {downloadedSounds.has(sound) ? <Check size={18} /> : <Download size={18} />}
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <Music size={24} className="text-white" />
          <div>
            <span className="text-white font-semibold block">Essential Pack</span>
            <span className="text-slate-400 text-sm">210 soundfonts</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors">
            <Download size={16} />
            Download All
          </button>
          <button 
            onClick={() => setCurrentScreen('mixer')}
            className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors"
          >
            <ChevronLeft size={18} className="text-slate-400" />
          </button>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-4 gap-3">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className="aspect-square rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors p-4 flex flex-col items-center justify-center gap-2"
              >
                <Icon size={32} className="text-slate-400" />
                <span className="text-white font-medium text-sm">{category.name}</span>
                <span className="text-cyan-400 text-xs">{category.count} sounds</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
