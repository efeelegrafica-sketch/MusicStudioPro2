import { useApp } from '@/store/AppContext';
import { Settings, ShoppingCart, Zap, Grid3X3, RefreshCw } from 'lucide-react';

export function Mixer() {
  const { 
    tracks, 
    updateTrackVolume, 
    toggleTrackMute, 
    toggleTrackSolo,
    setSelectedTrack,
    setCurrentScreen
  } = useApp();

  const handleVolumeChange = (trackId: number, value: number) => {
    updateTrackVolume(trackId, value);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Grid3X3 size={18} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Grid3X3 size={18} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <RefreshCw size={18} className="text-slate-400" />
          </button>
          <span className="text-white font-semibold ml-4">SYNTH MODULE</span>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-yellow-500/20 text-yellow-400">
            <span className="text-sm">76%</span>
            <span className="text-xs">4.3/6GB</span>
          </div>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <ShoppingCart size={18} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Zap size={18} className="text-slate-400" />
          </button>
          <button 
            onClick={() => setCurrentScreen('settings')}
            className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors"
          >
            <Settings size={18} className="text-slate-400" />
          </button>
        </div>
      </div>

      {/* Tracks */}
      <div className="flex-1 flex overflow-x-auto p-4 gap-2">
        {tracks.map((track) => (
          <div 
            key={track.id} 
            className="flex flex-col w-24 min-w-24 bg-slate-800 rounded-lg overflow-hidden"
          >
            {/* Track Header */}
            <div className="bg-slate-700 p-2 text-center">
              <span className="text-xs text-slate-400 block">Track {track.id}</span>
              <span className="text-sm text-white font-semibold truncate">{track.instrument}</span>
            </div>
            
            {/* Channel Info */}
            <div className="flex justify-between px-2 py-1 bg-slate-750">
              <span className="text-[10px] text-cyan-400">CH {track.id}</span>
              <span className="text-[10px] text-slate-500">S</span>
            </div>
            
            {/* Range */}
            <div className="flex justify-between px-2 py-1">
              <span className="text-[10px] text-slate-500">A0</span>
              <span className="text-[10px] text-slate-500">C8</span>
            </div>
            
            {/* Volume Fader */}
            <div className="flex-1 flex justify-center py-2">
              <div className="relative w-8 h-48 bg-slate-700 rounded-full">
                {/* Scale marks */}
                <div className="absolute inset-x-0 top-0 h-px bg-slate-600" />
                <div className="absolute inset-x-0 top-1/4 h-px bg-slate-600" />
                <div className="absolute inset-x-0 top-1/2 h-px bg-slate-500" />
                <div className="absolute inset-x-0 top-3/4 h-px bg-slate-600" />
                <div className="absolute inset-x-0 bottom-0 h-px bg-slate-600" />
                
                {/* Fader handle */}
                <div 
                  className="absolute left-0 right-0 h-8 bg-gradient-to-r from-slate-400 to-slate-500 rounded-full shadow-lg cursor-pointer"
                  style={{ 
                    top: `${((track.volume + 24) / 48) * 100}%`,
                    transform: 'translateY(-50%)'
                  }}
                />
                
                <input
                  type="range"
                  min="-24"
                  max="24"
                  step="0.5"
                  value={track.volume}
                  onChange={(e) => handleVolumeChange(track.id, parseFloat(e.target.value))}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  style={{ transform: 'rotate(180deg)' }}
                />
              </div>
            </div>
            
            {/* Volume Labels */}
            <div className="flex flex-col items-center gap-1 text-[10px] text-slate-500 py-1">
              <span>- 6</span>
              <span>- 0</span>
              <span>- -6</span>
              <span>- -12</span>
              <span>- -24</span>
              <span>- inf</span>
            </div>
            
            {/* Controls */}
            <div className="flex justify-center gap-1 p-2">
              <button
                onClick={() => toggleTrackMute(track.id)}
                className={`w-6 h-6 rounded text-[10px] font-bold transition-colors ${
                  track.muted ? 'bg-red-500 text-white' : 'bg-slate-600 text-slate-400'
                }`}
              >
                M
              </button>
              <button
                onClick={() => toggleTrackSolo(track.id)}
                className={`w-6 h-6 rounded text-[10px] font-bold transition-colors ${
                  track.solo ? 'bg-yellow-500 text-white' : 'bg-slate-600 text-slate-400'
                }`}
              >
                S
              </button>
            </div>
            
            {/* Bottom Buttons */}
            <div className="flex justify-center gap-1 p-2 border-t border-slate-700">
              <button 
                onClick={() => {
                  setSelectedTrack(track.id);
                  setCurrentScreen('fx');
                }}
                className="px-2 py-1 rounded bg-slate-700 text-slate-400 text-[10px] hover:bg-slate-600 transition-colors"
              >
                FX
              </button>
              <button className="px-2 py-1 rounded bg-slate-700 text-slate-400 text-[10px] hover:bg-slate-600 transition-colors">
                S
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-t border-slate-700">
        <div className="flex items-center gap-4">
          <button className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <span className="text-cyan-400 text-lg">+</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="text-cyan-400 text-sm">FX</span>
            <div className="w-20 h-1 bg-slate-700 rounded-full overflow-hidden">
              <div className="w-1/3 h-full bg-cyan-400" />
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <span>1:06 / 6:25</span>
        </div>
        
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Settings size={16} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Grid3X3 size={16} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Settings size={16} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Grid3X3 size={16} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Grid3X3 size={16} className="text-slate-400" />
          </button>
        </div>
      </div>
    </div>
  );
}
