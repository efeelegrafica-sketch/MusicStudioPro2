import React, { useState, useCallback } from 'react';
import { X } from 'lucide-react';

interface KeyProps {
  note: string;
  isBlack?: boolean;
  isActive?: boolean;
  onPress: (note: string) => void;
  onRelease: (note: string) => void;
}

const Key: React.FC<KeyProps> = ({ note, isBlack, isActive, onPress, onRelease }) => {
  return (
    <button
      className={`relative ${isBlack ? 'w-8 h-32 -mx-4 z-10' : 'w-12 h-48'} 
        ${isBlack 
          ? isActive 
            ? 'bg-gradient-to-b from-gray-600 to-gray-800' 
            : 'bg-gradient-to-b from-black to-gray-900'
          : isActive
            ? 'bg-gradient-to-b from-gray-300 to-gray-400'
            : 'bg-gradient-to-b from-white to-gray-200'
        }
        rounded-b-lg shadow-lg transition-all duration-75 active:scale-95`}
      onMouseDown={() => onPress(note)}
      onMouseUp={() => onRelease(note)}
      onMouseLeave={() => onRelease(note)}
      onTouchStart={() => onPress(note)}
      onTouchEnd={() => onRelease(note)}
    >
      {!isBlack && (
        <span className={`absolute bottom-2 left-1/2 -translate-x-1/2 text-xs ${
          isActive ? 'text-gray-600' : 'text-gray-400'
        }`}>
          {note}
        </span>
      )}
    </button>
  );
};

export function VirtualKeyboard() {
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());
  const [pitchBend, setPitchBend] = useState(0);
  const [modulation, setModulation] = useState(0);
  const [sustain, setSustain] = useState(false);

  const handleKeyPress = useCallback((note: string) => {
    setActiveKeys(prev => new Set(prev).add(note));
  }, []);

  const handleKeyRelease = useCallback((note: string) => {
    setActiveKeys(prev => {
      const newSet = new Set(prev);
      newSet.delete(note);
      return newSet;
    });
  }, []);

  const whiteKeys = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
  const blackKeys = ['C#', 'D#', null, 'F#', 'G#', 'A#', null];
  const octaves = [-2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8];

  const renderKeys = () => {
    const keys: React.ReactNode[] = [];
    
    octaves.forEach(octave => {
      whiteKeys.forEach((note, index) => {
        const fullNote = `${note}${octave}`;
        const hasBlackKey = blackKeys[index] !== null;
        
        keys.push(
          <div key={fullNote} className="relative flex">
            <Key
              note={fullNote}
              isActive={activeKeys.has(fullNote)}
              onPress={handleKeyPress}
              onRelease={handleKeyRelease}
            />
            {hasBlackKey && (
              <Key
                note={`${blackKeys[index]}${octave}`}
                isBlack
                isActive={activeKeys.has(`${blackKeys[index]}${octave}`)}
                onPress={handleKeyPress}
                onRelease={handleKeyRelease}
              />
            )}
          </div>
        );
      });
    });
    
    return keys;
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl overflow-hidden">
      {/* Controls */}
      <div className="flex items-center justify-between px-6 py-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center gap-6">
          {/* Pitch Bend */}
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-24 bg-gray-900 rounded-lg overflow-hidden relative">
              <div 
                className="absolute left-0 right-0 h-2 bg-yellow-500 rounded-full transition-all"
                style={{ top: `${50 - pitchBend}%`, transform: 'translateY(-50%)' }}
              />
              <input
                type="range"
                min="-100"
                max="100"
                value={pitchBend}
                onChange={(e) => setPitchBend(parseInt(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                style={{ transform: 'rotate(180deg)' }}
              />
            </div>
            <span className="text-xs text-yellow-500">PITCH</span>
          </div>
          
          {/* Modulation */}
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-24 bg-gray-900 rounded-lg overflow-hidden relative">
              <div 
                className="absolute left-0 right-0 h-2 bg-yellow-500 rounded-full transition-all"
                style={{ top: `${100 - modulation}%`, transform: 'translateY(-50%)' }}
              />
              <input
                type="range"
                min="0"
                max="100"
                value={modulation}
                onChange={(e) => setModulation(parseInt(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                style={{ transform: 'rotate(180deg)' }}
              />
            </div>
            <span className="text-xs text-yellow-500">MOD</span>
          </div>
          
          {/* Sustain */}
          <button
            onClick={() => setSustain(!sustain)}
            className={`w-16 h-16 rounded-lg flex items-center justify-center transition-colors ${
              sustain ? 'bg-yellow-500/30 border-2 border-yellow-500' : 'bg-gray-700 border-2 border-gray-600'
            }`}
          >
            <span className={`text-sm font-semibold ${sustain ? 'text-yellow-500' : 'text-gray-400'}`}>
              SUS
            </span>
          </button>
        </div>
        
        <button className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center hover:bg-gray-600 transition-colors">
          <X size={20} className="text-gray-400" />
        </button>
      </div>

      {/* Range Indicator */}
      <div className="flex items-center px-6 py-2 bg-gray-800">
        <div className="flex items-center gap-1 text-xs text-gray-500">
          <span>C-2</span>
          <div className="w-px h-4 bg-gray-600" />
          <span>C-1</span>
          <div className="w-px h-4 bg-gray-600" />
          <span>C0</span>
          <div className="h-6 w-0.5 bg-yellow-500" />
          <span className="text-yellow-500">C1</span>
          <span>C2</span>
          <span>C3</span>
          <span>C4</span>
          <span>C5</span>
          <div className="h-6 w-0.5 bg-yellow-500" />
          <span className="text-yellow-500">C6</span>
          <span>C7</span>
          <span>C8</span>
        </div>
      </div>

      {/* Keyboard */}
      <div className="flex-1 overflow-x-auto">
        <div className="flex justify-center min-w-max px-4 py-4">
          {renderKeys()}
        </div>
      </div>
    </div>
  );
}
