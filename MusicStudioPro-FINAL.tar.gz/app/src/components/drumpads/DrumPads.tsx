import { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { ChevronLeft } from 'lucide-react';

export function DrumPads() {
  const { drumPads, updateDrumPad, setCurrentScreen } = useApp();
  const [selectedPad, setSelectedPad] = useState<number | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const handlePadClick = (id: number) => {
    if (editMode) {
      setSelectedPad(id);
    } else {
      // Trigger sound
      const pad = drumPads.find(p => p.id === id);
      if (pad) {
        updateDrumPad(id, { velocity: 100 });
        setTimeout(() => updateDrumPad(id, { velocity: pad.velocity }), 100);
      }
    }
  };

  const currentPads = drumPads.slice((currentPage - 1) * 16, currentPage * 16);

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setCurrentScreen('mixer')}
            className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors"
          >
            <ChevronLeft size={18} className="text-slate-400" />
          </button>
          <span className="text-white font-semibold">Drum Pads</span>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-400 text-sm">
            EDIT MODE
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Pads Grid */}
        <div className="flex-1 p-4">
          <div className="grid grid-cols-4 gap-3 h-full">
            {currentPads.map((pad) => (
              <button
                key={pad.id}
                onClick={() => handlePadClick(pad.id)}
                className={`relative rounded-xl transition-all duration-100 active:scale-95 ${
                  selectedPad === pad.id
                    ? 'bg-cyan-500/30 border-2 border-cyan-400'
                    : 'bg-slate-800 border-2 border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className="absolute top-2 left-2 text-xs text-slate-500">{pad.id}</div>
                <div className="flex flex-col items-center justify-center h-full">
                  <span className={`text-sm font-semibold ${
                    selectedPad === pad.id ? 'text-cyan-400' : 'text-slate-400'
                  }`}>
                    {pad.name}
                  </span>
                  {pad.velocity > 0 && (
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-8 h-1 bg-cyan-400 rounded-full" 
                      style={{ opacity: pad.velocity / 100 }}
                    />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Panel */}
        <div className="w-64 bg-slate-800 border-l border-slate-700 p-4">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm">MIDI LEARN</span>
            <button className="px-3 py-1.5 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">
              MIDI LEARN
            </button>
          </div>
          
          <div className="flex gap-2 mb-4">
            <button className="flex-1 py-2 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">
              LIVE SET
            </button>
            <button className="flex-1 py-2 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">
              CONTINUO
            </button>
          </div>
          
          <div className="flex gap-2 mb-4">
            <button className="flex-1 py-2 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">
              SAVE
            </button>
            <button 
              onClick={() => setEditMode(!editMode)}
              className={`flex-1 py-2 rounded-lg text-sm transition-colors ${
                editMode ? 'bg-orange-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              EDIT
            </button>
          </div>
          
          <div className="flex justify-center gap-2 mb-6">
            {[1, 2, 3, 4].map(page => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-10 h-10 rounded-lg font-semibold transition-colors ${
                  currentPage === page
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                }`}
              >
                {page}
              </button>
            ))}
          </div>
          
          <div className="border-t border-slate-700 pt-4">
            <span className="text-slate-400 text-sm block mb-2">MASTER VOLUME</span>
            <div className="relative h-4 bg-slate-700 rounded-full overflow-hidden">
              <div className="absolute inset-y-0 left-0 w-3/4 bg-gradient-to-r from-cyan-500 to-cyan-400 rounded-full" />
              <input
                type="range"
                min="0"
                max="100"
                defaultValue={75}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Edit Pad Modal */}
      {selectedPad && editMode && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-slate-800 rounded-xl p-6 w-80">
            <div className="flex items-center justify-between mb-4">
              <span className="text-white font-semibold">Edit Pad {selectedPad}</span>
              <button 
                onClick={() => setSelectedPad(null)}
                className="text-slate-400 hover:text-white"
              >
                <ChevronLeft size={20} />
              </button>
            </div>
            
            <div className="space-y-3">
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <span className="text-slate-300">Pad Sound</span>
                <div className="flex items-center gap-2 text-slate-400">
                  <span>LOW A</span>
                  <ChevronLeft size={16} className="rotate-180" />
                </div>
              </button>
              
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <span className="text-slate-300">Pad Parameters</span>
                <ChevronLeft size={16} className="rotate-180 text-slate-400" />
              </button>
              
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <span className="text-slate-300">Pad Velocity</span>
                <ChevronLeft size={16} className="rotate-180 text-slate-400" />
              </button>
              
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <span className="text-slate-300">Pad Volume</span>
                <ChevronLeft size={16} className="rotate-180 text-slate-400" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
