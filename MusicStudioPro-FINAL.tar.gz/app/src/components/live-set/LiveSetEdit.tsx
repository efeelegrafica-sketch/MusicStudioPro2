import { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { Grid3X3, RefreshCw, Zap, ChevronLeft, Plus } from 'lucide-react';

interface Preset {
  id: string;
  name: string;
  bank: string;
  page: string;
}

const banks = ['User 1', 'User 2', 'User 3', 'User 4'];
const pages = ['SHOW PARTE A', 'SHOW PARTE B', 'SHOW PARTE C', 'Live Set Page 4'];

const defaultPresets: Preset[] = [
  { id: '1', name: 'CFX', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '2', name: 'CFX+EP', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '3', name: 'CFX+PAD', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '4', name: 'CFX+STRINGS', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '5', name: 'EP SOLO', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '6', name: 'CFX+D50', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '7', name: 'ORGAN', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '8', name: 'STRINGS/ATACK', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '9', name: 'CFX+BASS', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '10', name: 'Sanfona', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '11', name: 'Moog saw', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '12', name: 'Moog', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '13', name: 'Brass', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '14', name: 'Metaleira', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '15', name: 'Trumpet', bank: 'User 1', page: 'SHOW PARTE A' },
  { id: '16', name: 'Choir', bank: 'User 1', page: 'SHOW PARTE A' },
];

export function LiveSetEdit() {
  const [selectedBank, setSelectedBank] = useState('User 1');
  const [selectedPage, setSelectedPage] = useState('SHOW PARTE A');
  const [selectedPreset, setSelectedPreset] = useState<string | null>('2');
  const [showBankPageSelector, setShowBankPageSelector] = useState(false);
  const { setCurrentScreen } = useApp();

  const filteredPresets = defaultPresets.filter(p => 
    p.bank === selectedBank && p.page === selectedPage
  );

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Grid3X3 size={18} className="text-slate-400" />
          </button>
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <RefreshCw size={18} className="text-slate-400" />
          </button>
          <span className="text-white font-semibold text-lg">LIVE SET EDIT</span>
        </div>
        
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors">
            <Zap size={18} className="text-slate-400" />
          </button>
          <button 
            onClick={() => setCurrentScreen('mixer')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
          >
            <ChevronLeft size={16} />
            Back
          </button>
        </div>
      </div>

      {/* Bank/Page Selector */}
      {showBankPageSelector && (
        <div className="flex gap-4 p-4 bg-slate-800/50 border-b border-slate-700">
          <div className="flex-1">
            <span className="text-slate-400 text-sm block mb-2">BANK</span>
            <div className="space-y-1">
              {banks.map(bank => (
                <button
                  key={bank}
                  onClick={() => setSelectedBank(bank)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    selectedBank === bank
                      ? 'bg-cyan-500/20 text-cyan-400 border-l-4 border-cyan-400'
                      : 'text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {bank}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1">
            <span className="text-slate-400 text-sm block mb-2">PAGE</span>
            <div className="space-y-1">
              {pages.map(page => (
                <button
                  key={page}
                  onClick={() => setSelectedPage(page)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    selectedPage === page
                      ? 'bg-cyan-500/20 text-cyan-400 border-l-4 border-cyan-400'
                      : 'text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {page}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Presets Grid */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="grid grid-cols-4 gap-3">
          {Array.from({ length: 16 }, (_, i) => {
            const preset = filteredPresets[i];
            const isSelected = preset?.id === selectedPreset;
            const isEmpty = !preset;
            
            return (
              <button
                key={i}
                onClick={() => {
                  if (preset) {
                    setSelectedPreset(preset.id);
                  }
                }}
                className={`aspect-[2/1] rounded-xl transition-all ${
                  isSelected
                    ? 'bg-cyan-500/30 border-2 border-cyan-400 shadow-lg shadow-cyan-500/20'
                    : isEmpty
                      ? 'bg-slate-800 border-2 border-slate-700 border-dashed'
                      : 'bg-slate-800 border-2 border-slate-700 hover:border-slate-600'
                }`}
              >
                {isEmpty ? (
                  <div className="flex items-center justify-center h-full">
                    <Plus size={24} className="text-slate-600" />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full p-2">
                    <span className={`font-semibold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                      {preset.name}
                    </span>
                    {isSelected && (
                      <div className="w-8 h-1 bg-cyan-400 rounded-full mt-2" />
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-t border-slate-700">
        <button 
          onClick={() => setShowBankPageSelector(!showBankPageSelector)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
        >
          <Grid3X3 size={16} />
          {selectedBank} - {selectedPage}
        </button>
        
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-sm">38:06 / 56:16</span>
        </div>
      </div>
    </div>
  );
}
