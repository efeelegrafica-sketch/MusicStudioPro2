import { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { X, Zap, Clock, Cpu, ChevronDown, Check } from 'lucide-react';

const moduleCategories = [
  { id: 'dynamics', name: 'DYNAMICS', description: 'Compression & Color', icon: Zap, color: 'purple' },
  { id: 'timespace', name: 'TIME & SPACE', description: 'Delay, Reverb & Mod', icon: Clock, color: 'cyan' },
  { id: 'synthesis', name: 'SYNTHESIS', description: 'Articulation & Control', icon: Cpu, color: 'orange' },
];

export function FXModules() {
  const { fxModules, toggleFXModule, updateFXParam, selectedTrack } = useApp();
  const [selectedCategory, setSelectedCategory] = useState('timespace');

  const renderKnob = (label: string, value: number, param: string, moduleId: string, unit: string = '') => (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-14 h-14">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-slate-400 to-slate-600 shadow-lg">
          <div 
            className="absolute inset-2 rounded-full bg-gradient-to-br from-slate-300 to-slate-500"
            style={{ transform: `rotate(${(value / 127) * 270 - 135}deg)` }}
          >
            <div className="absolute top-1 left-1/2 w-0.5 h-3 bg-yellow-400 -translate-x-1/2" />
          </div>
        </div>
        <input
          type="range"
          min="0"
          max="127"
          value={value}
          onChange={(e) => updateFXParam(moduleId, param, parseInt(e.target.value))}
          className="absolute inset-0 opacity-0 cursor-pointer"
        />
      </div>
      <span className="text-[10px] text-slate-400 uppercase">{label}</span>
      <span className="text-xs text-slate-300">{value}{unit}</span>
    </div>
  );

  const renderTremolo = () => (
    <div className="bg-gradient-to-br from-emerald-900/50 to-emerald-800/30 rounded-xl p-4 border border-emerald-700/30">
      <div className="flex items-center justify-between mb-4">
        <span className="text-emerald-400 font-semibold italic text-lg">Tremolo</span>
        <button
          onClick={() => toggleFXModule('tremolo')}
          className={`w-12 h-6 rounded-full transition-colors ${
            fxModules.find(m => m.id === 'tremolo')?.enabled ? 'bg-emerald-500' : 'bg-slate-600'
          }`}
        >
          <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
            fxModules.find(m => m.id === 'tremolo')?.enabled ? 'translate-x-6' : 'translate-x-0.5'
          }`} />
        </button>
      </div>
      
      <div className="flex items-center gap-2 mb-4">
        <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-800 text-emerald-300 text-sm">
          Sine
          <ChevronDown size={14} />
        </button>
        <label className="flex items-center gap-2 text-emerald-300 text-sm cursor-pointer">
          <div className="w-4 h-4 rounded bg-emerald-500 flex items-center justify-center">
            <Check size={12} className="text-white" />
          </div>
          Retrig
        </label>
      </div>
      
      <div className="flex justify-between">
        {renderKnob('FRQ', fxModules.find(m => m.id === 'tremolo')?.params.FRQ || 64, 'FRQ', 'tremolo')}
        {renderKnob('FADE', fxModules.find(m => m.id === 'tremolo')?.params.FADE || 6, 'FADE', 'tremolo')}
        {renderKnob('PHS', fxModules.find(m => m.id === 'tremolo')?.params.PHS || 0, 'PHS', 'tremolo')}
        {renderKnob('JNT', fxModules.find(m => m.id === 'tremolo')?.params.JNT || 64, 'JNT', 'tremolo')}
      </div>
      
      <button className="w-full mt-4 py-2 text-emerald-400 text-sm hover:text-emerald-300 transition-colors">
        OPEN EDITOR
      </button>
    </div>
  );

  const renderDelay = () => (
    <div className="bg-gradient-to-br from-rose-900/50 to-rose-800/30 rounded-xl p-4 border border-rose-700/30">
      <div className="flex items-center justify-between mb-4">
        <div>
          <span className="text-rose-400 font-bold text-lg">D-DELAY</span>
          <span className="text-rose-500 text-sm ml-2">RACK</span>
        </div>
        <button
          onClick={() => toggleFXModule('delay')}
          className={`w-12 h-6 rounded-full transition-colors ${
            fxModules.find(m => m.id === 'delay')?.enabled ? 'bg-rose-500' : 'bg-slate-600'
          }`}
        >
          <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
            fxModules.find(m => m.id === 'delay')?.enabled ? 'translate-x-6' : 'translate-x-0.5'
          }`} />
        </button>
      </div>
      
      <div className="bg-black/50 rounded-lg p-4 mb-4">
        <div className="text-rose-500 text-3xl font-mono text-center">64ms</div>
      </div>
      
      <button className="w-full py-2 text-rose-400 text-sm hover:text-rose-300 transition-colors">
        EDIT PARAMS
      </button>
    </div>
  );

  const renderReverb = () => (
    <div className="bg-gradient-to-br from-indigo-900/50 to-indigo-800/30 rounded-xl p-4 border border-indigo-700/30">
      <div className="flex items-center justify-between mb-4">
        <span className="text-indigo-300 font-semibold text-lg">SPACE</span>
        <button
          onClick={() => toggleFXModule('reverb')}
          className={`w-12 h-6 rounded-full transition-colors ${
            fxModules.find(m => m.id === 'reverb')?.enabled ? 'bg-indigo-500' : 'bg-slate-600'
          }`}
        >
          <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
            fxModules.find(m => m.id === 'reverb')?.enabled ? 'translate-x-6' : 'translate-x-0.5'
          }`} />
        </button>
      </div>
      
      <div className="flex items-center justify-center py-6">
        <div className="w-20 h-20 rounded-full border-2 border-indigo-500/50 flex items-center justify-center">
          <div className="text-center">
            <span className="text-indigo-400 text-xs">VERB</span>
            <span className="text-indigo-500 text-xs block">ALGO-X</span>
          </div>
        </div>
      </div>
      
      <button className="w-full py-2 text-indigo-400 text-sm hover:text-indigo-300 transition-colors">
        OPEN DESIGNER
      </button>
    </div>
  );

  const renderCompressor = () => (
    <div className="bg-gradient-to-br from-amber-900/50 to-amber-800/30 rounded-xl p-4 border border-amber-700/30">
      <div className="flex items-center justify-between mb-4">
        <div>
          <span className="text-amber-400 font-bold text-lg">VCA-COMP</span>
          <span className="text-amber-500 text-xs block">DYNAMICS PROC</span>
        </div>
        <button
          onClick={() => toggleFXModule('compressor')}
          className={`w-12 h-6 rounded-full transition-colors ${
            fxModules.find(m => m.id === 'compressor')?.enabled ? 'bg-amber-500' : 'bg-slate-600'
          }`}
        >
          <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
            fxModules.find(m => m.id === 'compressor')?.enabled ? 'translate-x-6' : 'translate-x-0.5'
          }`} />
        </button>
      </div>
      
      <div className="grid grid-cols-4 gap-2 mb-2">
        {renderKnob('THR', fxModules.find(m => m.id === 'compressor')?.params.THR || 64, 'THR', 'compressor')}
        {renderKnob('RAT', fxModules.find(m => m.id === 'compressor')?.params.RAT || 64, 'RAT', 'compressor')}
        {renderKnob('ATT', fxModules.find(m => m.id === 'compressor')?.params.ATT || 64, 'ATT', 'compressor')}
        {renderKnob('REL', fxModules.find(m => m.id === 'compressor')?.params.REL || 64, 'REL', 'compressor')}
      </div>
      <div className="grid grid-cols-3 gap-2">
        {renderKnob('KNE', fxModules.find(m => m.id === 'compressor')?.params.KNE || 32, 'KNE', 'compressor')}
        {renderKnob('MIX', fxModules.find(m => m.id === 'compressor')?.params.MIX || 127, 'MIX', 'compressor')}
        {renderKnob('GAN', fxModules.find(m => m.id === 'compressor')?.params.GAN || 64, 'GAN', 'compressor')}
      </div>
    </div>
  );

  return (
    <div className="flex h-full bg-slate-900 rounded-xl overflow-hidden">
      {/* Left Sidebar */}
      <div className="w-64 bg-slate-800 border-r border-slate-700 p-4">
        <h3 className="text-slate-400 text-sm font-semibold mb-4">MODULES</h3>
        <div className="space-y-2">
          {moduleCategories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-gradient-to-r from-purple-600 to-purple-800'
                    : 'bg-slate-700 hover:bg-slate-600'
                }`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  selectedCategory === cat.id ? 'bg-purple-500/30' : 'bg-slate-600'
                }`}>
                  <Icon size={20} className={selectedCategory === cat.id ? 'text-purple-300' : 'text-slate-400'} />
                </div>
                <div className="text-left">
                  <span className={`block font-semibold ${selectedCategory === cat.id ? 'text-white' : 'text-slate-300'}`}>
                    {cat.name}
                  </span>
                  <span className={`text-xs ${selectedCategory === cat.id ? 'text-purple-300' : 'text-slate-500'}`}>
                    {cat.description}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-white font-semibold">FX | Track {selectedTrack}</h2>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
              <span className="text-cyan-400 text-xs">M</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
              <Zap size={14} className="text-slate-400" />
            </div>
            <button className="text-slate-400 hover:text-white">
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {renderTremolo()}
          {renderDelay()}
          {renderReverb()}
          {renderCompressor()}
        </div>
      </div>
    </div>
  );
}
