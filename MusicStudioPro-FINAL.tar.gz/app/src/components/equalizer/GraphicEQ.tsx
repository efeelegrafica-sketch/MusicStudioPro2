import { useApp } from '@/store/AppContext';
import { X, RotateCcw } from 'lucide-react';

export function GraphicEQ() {
  const { 
    eqBands, 
    updateEQBand, 
    powerOn, 
    setPowerOn, 
    selectedChannel, 
    setSelectedChannel 
  } = useApp();

  const handleBandChange = (index: number, value: number) => {
    if (!powerOn) return;
    updateEQBand(index, value);
  };

  const resetEQ = () => {
    eqBands.forEach((_, index) => updateEQBand(index, 0));
  };

  const getBarColor = (gain: number) => {
    if (gain > 0) return `rgb(${255}, ${200 - gain * 2}, ${50})`;
    if (gain < 0) return `rgb(${50}, ${200 + gain * 2}, ${255})`;
    return '#64748b';
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-4">
          <span className="text-white font-semibold text-lg">RIGHT</span>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-slate-400 to-slate-600 shadow-lg flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-300 to-slate-500 shadow-inner" />
            </div>
            <span className="text-xs text-slate-400 mt-1">Volume</span>
            <span className="text-xs text-slate-300">0 dB</span>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex flex-col items-center gap-2">
            <span className="text-sm text-slate-300">POWER</span>
            <button
              onClick={() => setPowerOn(!powerOn)}
              className={`w-12 h-6 rounded-full transition-colors ${
                powerOn ? 'bg-cyan-500' : 'bg-slate-600'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                powerOn ? 'translate-x-6' : 'translate-x-0.5'
              }`} />
            </button>
          </div>
          <button className="text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>
      </div>

      {/* EQ Bands */}
      <div className="flex-1 flex items-end justify-center gap-1 px-2 py-4 overflow-x-auto">
        {eqBands.map((band, index) => {
          const height = Math.abs(band.gain) * 3 + 10;
          const isPositive = band.gain >= 0;
          
          return (
            <div key={index} className="flex flex-col items-center gap-1 min-w-[24px]">
              <div className="relative w-5 h-48 bg-slate-800 rounded-full overflow-hidden">
                {/* Center line */}
                <div className="absolute inset-x-0 top-1/2 h-px bg-slate-600" />
                
                {/* Bar */}
                <div
                  className="absolute left-0 right-0 rounded-full transition-all duration-150"
                  style={{
                    height: `${height}%`,
                    [isPositive ? 'bottom' : 'top']: '50%',
                    backgroundColor: getBarColor(band.gain),
                    opacity: powerOn ? 1 : 0.3,
                  }}
                />
                
                {/* Click area */}
                <input
                  type="range"
                  min="-12"
                  max="12"
                  step="0.5"
                  value={band.gain}
                  onChange={(e) => handleBandChange(index, parseFloat(e.target.value))}
                  disabled={!powerOn}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  style={{ transform: 'rotate(180deg)' }}
                />
              </div>
              <span className="text-[10px] text-slate-400 rotate-0 whitespace-nowrap">
                {band.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Right Panel */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-t border-slate-700">
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedChannel('LEFT')}
            className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
              selectedChannel === 'LEFT'
                ? 'bg-cyan-500 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            LEFT
          </button>
          <button
            onClick={() => setSelectedChannel('RIGHT')}
            className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
              selectedChannel === 'RIGHT'
                ? 'bg-cyan-500 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            RIGHT
          </button>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="px-6 py-2 rounded-lg bg-slate-700 text-slate-300 font-semibold hover:bg-slate-600 transition-colors">
            LINK
          </button>
          <div className="w-10 h-10 rounded-full bg-cyan-500 flex items-center justify-center text-white text-xs font-bold">
            05:12
          </div>
          <button
            onClick={resetEQ}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
          >
            <RotateCcw size={16} />
            RESET
          </button>
        </div>
      </div>
    </div>
  );
}
