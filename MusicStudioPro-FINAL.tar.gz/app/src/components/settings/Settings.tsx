import { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { X, Settings as SettingsIcon, Cpu, Music, RotateCw } from 'lucide-react';

export function Settings() {
  const { settings, updateSetting, setCurrentScreen } = useApp();
  const [activeTab, setActiveTab] = useState<'general' | 'system'>('general');

  const sampleRates = [44100, 48000, 88200, 96000];
  const bufferSizes = [64, 128, 256, 384, 512, 640, 768, 896, 1024];
  const velocityCurves = ['Soft', 'Linear', 'Medium', 'Hard'];
  const interpolationQualities = ['Low', 'Mid', 'High', 'Ultra'];

  return (
    <div className="flex items-center justify-center min-h-screen bg-black/50 p-4">
      <div className="w-full max-w-md bg-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-700 border-b border-slate-600">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('general')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'general'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-600 text-slate-300 hover:bg-slate-500'
              }`}
            >
              <SettingsIcon size={16} />
              General
            </button>
            <button
              onClick={() => setActiveTab('system')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'system'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-600 text-slate-300 hover:bg-slate-500'
              }`}
            >
              <Cpu size={16} />
              System
            </button>
          </div>
          <button 
            onClick={() => setCurrentScreen('mixer')}
            className="text-slate-400 hover:text-white"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 max-h-[70vh] overflow-y-auto">
          {activeTab === 'general' ? (
            <div className="space-y-4">
              {/* Sample Rate */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium">Sample Rate</span>
                  <div className="relative">
                    <select
                      value={settings.sampleRate}
                      onChange={(e) => updateSetting('sampleRate', parseInt(e.target.value))}
                      className="appearance-none bg-slate-600 text-white px-4 py-2 pr-8 rounded-lg cursor-pointer"
                    >
                      {sampleRates.map(rate => (
                        <option key={rate} value={rate}>{rate} Hz</option>
                      ))}
                    </select>
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>

              {/* Buffer Size */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white font-medium">Buffer Size</span>
                  <span className="text-cyan-400 font-mono">{settings.bufferSize} frames</span>
                </div>
                <div className="relative h-6 bg-slate-600 rounded-full">
                  <div 
                    className="absolute top-0 bottom-0 left-0 bg-pink-500 rounded-full"
                    style={{ width: `${(bufferSizes.indexOf(settings.bufferSize) / (bufferSizes.length - 1)) * 100}%` }}
                  />
                  <input
                    type="range"
                    min="0"
                    max={bufferSizes.length - 1}
                    step="1"
                    value={bufferSizes.indexOf(settings.bufferSize)}
                    onChange={(e) => updateSetting('bufferSize', bufferSizes[parseInt(e.target.value)])}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>
                <div className="flex justify-between mt-2 text-xs text-slate-400">
                  {bufferSizes.filter((_, i) => i % 2 === 0).map(size => (
                    <span key={size}>{size}</span>
                  ))}
                </div>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-slate-400 text-sm">LATENCY</span>
                  <span className="text-cyan-400 text-sm">{settings.latency}</span>
                </div>
                <div className="flex gap-2 mt-3">
                  {['ULTRA LOW', 'MEDIUM', 'HIGH'].map(latency => (
                    <button
                      key={latency}
                      onClick={() => updateSetting('latency', latency === 'ULTRA LOW' ? '4.00 ms' : latency === 'MEDIUM' ? '8.00 ms' : '16.00 ms')}
                      className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${
                        (latency === 'ULTRA LOW' && settings.latency === '4.00 ms') ||
                        (latency === 'MEDIUM' && settings.latency === '8.00 ms') ||
                        (latency === 'HIGH' && settings.latency === '16.00 ms')
                          ? 'bg-slate-600 text-white'
                          : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                      }`}
                    >
                      {latency}
                    </button>
                  ))}
                </div>
              </div>

              {/* Polyphony */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white font-medium">Polyphony</span>
                  <span className="text-cyan-400 font-mono">{settings.polyphony} voices</span>
                </div>
                <div className="relative h-6 bg-slate-600 rounded-full">
                  <div 
                    className="absolute top-0 bottom-0 left-0 bg-cyan-500 rounded-full"
                    style={{ width: `${(settings.polyphony / 500) * 100}%` }}
                  />
                  <input
                    type="range"
                    min="1"
                    max="500"
                    value={settings.polyphony}
                    onChange={(e) => updateSetting('polyphony', parseInt(e.target.value))}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>
              </div>

              {/* Velocity Curve */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white font-medium">Velocity Curve</span>
                  <span className="text-cyan-400">{settings.velocityCurve}</span>
                </div>
                <div className="flex gap-2">
                  {velocityCurves.map(curve => (
                    <button
                      key={curve}
                      onClick={() => updateSetting('velocityCurve', curve)}
                      className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
                        settings.velocityCurve === curve
                          ? 'bg-purple-600 text-white'
                          : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                      }`}
                    >
                      {curve}
                    </button>
                  ))}
                </div>
              </div>

              {/* Master Tune */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white font-medium">Master Tune</span>
                  <span className="text-cyan-400 font-mono">{settings.masterTune} cents</span>
                </div>
                <div className="relative h-6 bg-slate-600 rounded-full">
                  <div 
                    className="absolute top-1/2 left-1/2 w-4 h-4 bg-cyan-400 rounded-full -translate-y-1/2 -translate-x-1/2"
                    style={{ left: `${50 + (settings.masterTune / 100) * 50}%` }}
                  />
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.masterTune}
                    onChange={(e) => updateSetting('masterTune', parseInt(e.target.value))}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>
                <span className="text-xs text-slate-500 mt-2 block">Double tap to reset</span>
              </div>

              {/* Toggle Options */}
              <div className="space-y-3">
                {[
                  { key: 'invertPedal', label: 'Invert Pedal', desc: 'For Yamaha/Kawai style pedals' },
                  { key: 'hideMaster', label: 'Hide Master', desc: 'Removes the Master fader from Mixer' },
                  { key: 'monoOutput', label: 'Mono Output', desc: 'Sums L+R to mono (mono interfaces)' },
                ].map(({ key, label, desc }) => (
                  <div key={key} className="bg-slate-700/50 rounded-xl p-4 flex items-center justify-between">
                    <div>
                      <span className="text-white font-medium block">{label}</span>
                      <span className="text-slate-400 text-sm">{desc}</span>
                    </div>
                    <button
                      onClick={() => updateSetting(key as keyof typeof settings, !settings[key as keyof typeof settings] as never)}
                      className={`w-12 h-6 rounded-full transition-colors ${
                        settings[key as keyof typeof settings] ? 'bg-cyan-500' : 'bg-slate-600'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        settings[key as keyof typeof settings] ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Line Out */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                      <Music size={20} className="text-cyan-400" />
                    </div>
                    <div>
                      <span className="text-white font-medium block">Line Out</span>
                      <span className="text-slate-400 text-sm">Output to mixer/interface</span>
                    </div>
                  </div>
                  <button
                    onClick={() => updateSetting('lineOut', !settings.lineOut)}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      settings.lineOut ? 'bg-cyan-500' : 'bg-slate-600'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      settings.lineOut ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
                <div className="bg-slate-800/50 rounded-lg p-3 mt-3">
                  <p className="text-slate-400 text-sm">
                    <span className="text-cyan-400">-20dB</span> Reduces gain by -20dB to convert headphone output (amplified) to professional line level. Ideal for connecting to mixers and audio interfaces.
                  </p>
                </div>
              </div>

              {/* Master Limiter */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                      <SettingsIcon size={20} className="text-yellow-400" />
                    </div>
                    <div>
                      <span className="text-white font-medium block">Master Limiter</span>
                      <span className="text-slate-400 text-sm">Professional maximizer for punch</span>
                    </div>
                  </div>
                  <button
                    onClick={() => updateSetting('masterLimiter', !settings.masterLimiter)}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      settings.masterLimiter ? 'bg-yellow-500' : 'bg-slate-600'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      settings.masterLimiter ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
                
                {settings.masterLimiter && (
                  <div className="space-y-3 mt-4">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-slate-400 text-sm">THRESHOLD</span>
                        <span className="text-yellow-400 text-sm">-1.0 dB</span>
                      </div>
                      <div className="relative h-4 bg-slate-600 rounded-full">
                        <div className="absolute top-0 bottom-0 left-0 w-3/4 bg-yellow-500 rounded-full" />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-slate-400 text-sm">MAKEUP GAIN</span>
                        <span className="text-yellow-400 text-sm">+3.0 dB</span>
                      </div>
                      <div className="relative h-4 bg-slate-600 rounded-full">
                        <div className="absolute top-0 bottom-0 left-0 w-1/2 bg-yellow-500 rounded-full" />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-slate-400 text-sm">CEILING</span>
                        <span className="text-yellow-400 text-sm">-0.1 dB</span>
                      </div>
                      <div className="relative h-4 bg-slate-600 rounded-full">
                        <div className="absolute top-0 bottom-0 left-0 w-[95%] bg-yellow-500 rounded-full" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Interpolation Quality */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    <Music size={20} className="text-purple-400" />
                  </div>
                  <div>
                    <span className="text-white font-medium block">Interpolation Quality</span>
                    <span className="text-slate-400 text-sm">SoundFont sample interpolation method</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-3">
                  <span className="text-slate-400 text-sm">QUALITY PRESET</span>
                  <span className="text-white text-sm">{settings.interpolationQuality}</span>
                </div>
                
                <div className="grid grid-cols-4 gap-2">
                  {interpolationQualities.map(quality => (
                    <button
                      key={quality}
                      onClick={() => updateSetting('interpolationQuality', quality)}
                      className={`p-3 rounded-xl flex flex-col items-center gap-2 transition-colors ${
                        settings.interpolationQuality === quality
                          ? 'bg-purple-600'
                          : 'bg-slate-700 hover:bg-slate-600'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        settings.interpolationQuality === quality
                          ? 'bg-purple-500/30'
                          : 'bg-slate-600'
                      }`}>
                        {quality === 'Low' && <SettingsIcon size={16} className="text-yellow-400" />}
                        {quality === 'Mid' && <Music size={16} className="text-purple-400" />}
                        {quality === 'High' && <SettingsIcon size={16} className="text-cyan-400" />}
                        {quality === 'Ultra' && <Music size={16} className="text-white" />}
                      </div>
                      <span className={`text-xs font-medium ${
                        settings.interpolationQuality === quality ? 'text-white' : 'text-slate-400'
                      }`}>
                        {quality.toUpperCase()}
                      </span>
                      <span className={`text-[10px] ${
                        settings.interpolationQuality === quality ? 'text-purple-300' : 'text-slate-500'
                      }`}>
                        {quality === 'Low' && 'Linear'}
                        {quality === 'Mid' && '4th Order'}
                        {quality === 'High' && 'Sinc + 2x'}
                        {quality === 'Ultra' && 'Sinc + 4x'}
                      </span>
                    </button>
                  ))}
                </div>
                
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <span className="text-slate-400 text-xs block mb-1">CPU USAGE</span>
                    <span className="text-white font-medium">Balanced</span>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <span className="text-slate-400 text-xs block mb-1">AUDIO QUALITY</span>
                    <span className="text-white font-medium">Very Good</span>
                  </div>
                </div>
              </div>

              {/* System Actions */}
              <div className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                    <RotateCw size={20} className="text-red-400" />
                  </div>
                  <div>
                    <span className="text-white font-medium block">System Actions</span>
                    <span className="text-slate-400 text-sm">Advanced system controls</span>
                  </div>
                </div>
                
                <button className="w-full py-3 rounded-xl bg-red-500/20 border border-red-500/50 text-red-400 font-medium flex items-center justify-center gap-2 hover:bg-red-500/30 transition-colors">
                  <RotateCw size={18} />
                  FULL RESTART (Reboot Audio)
                </button>
                <p className="text-slate-400 text-sm mt-3 text-center">
                  Use this if audio stops working or becomes distorted. This will completely reload the application.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
