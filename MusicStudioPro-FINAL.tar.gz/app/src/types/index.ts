export interface EQBand {
  frequency: number;
  gain: number;
  label: string;
}

export interface FXModule {
  id: string;
  name: string;
  enabled: boolean;
  params: Record<string, number>;
}

export interface Track {
  id: number;
  name: string;
  instrument: string;
  volume: number;
  pan: number;
  muted: boolean;
  solo: boolean;
  fx: FXModule[];
}

export interface Soundfont {
  id: string;
  name: string;
  category: string;
  downloaded: boolean;
}

export interface DrumPad {
  id: number;
  name: string;
  sound: string;
  velocity: number;
  volume: number;
  color: string;
}

export interface LiveSetPreset {
  id: string;
  name: string;
  bank: string;
  page: string;
}

export interface ReverbPreset {
  id: string;
  name: string;
  decay: number;
  tone: number;
  size: number;
  mix: number;
}

export interface AppSettings {
  sampleRate: number;
  bufferSize: number;
  polyphony: number;
  masterTune: number;
  latency: string;
  velocityCurve: string;
  interpolationQuality: string;
  lineOut: boolean;
  masterLimiter: boolean;
  invertPedal: boolean;
  hideMaster: boolean;
  monoOutput: boolean;
}
