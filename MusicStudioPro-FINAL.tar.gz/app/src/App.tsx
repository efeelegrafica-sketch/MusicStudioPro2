import { AppProvider, useApp } from '@/store/AppContext';
import { GraphicEQ } from '@/components/equalizer/GraphicEQ';
import { FXModules } from '@/components/fx/FXModules';
import { Mixer } from '@/components/mixer/Mixer';
import { VirtualKeyboard } from '@/components/keyboard/VirtualKeyboard';
import { DrumPads } from '@/components/drumpads/DrumPads';
import { Settings } from '@/components/settings/Settings';
import { SoundfontLibrary } from '@/components/soundfonts/SoundfontLibrary';
import { LiveSetEdit } from '@/components/live-set/LiveSetEdit';
import { 
  Sliders, 
  Zap, 
  Keyboard, 
  Grid3X3, 
  Music,
  Layers,
  Volume2
} from 'lucide-react';

function Navigation() {
  const { currentScreen, setCurrentScreen } = useApp();

  const navItems = [
    { id: 'mixer', icon: Sliders, label: 'Mixer' },
    { id: 'eq', icon: Volume2, label: 'EQ' },
    { id: 'fx', icon: Zap, label: 'FX' },
    { id: 'keyboard', icon: Keyboard, label: 'Keys' },
    { id: 'drums', icon: Grid3X3, label: 'Pads' },
    { id: 'soundfonts', icon: Music, label: 'Sounds' },
    { id: 'liveset', icon: Layers, label: 'Live' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-700 z-50">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setCurrentScreen(item.id)}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-colors ${
                isActive 
                  ? 'bg-cyan-500/20 text-cyan-400' 
                  : 'text-slate-400 hover:text-slate-300'
              }`}
            >
              <Icon size={24} />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function MainContent() {
  const { currentScreen } = useApp();

  switch (currentScreen) {
    case 'mixer':
      return <Mixer />;
    case 'eq':
      return <GraphicEQ />;
    case 'fx':
      return <FXModules />;
    case 'keyboard':
      return <VirtualKeyboard />;
    case 'drums':
      return <DrumPads />;
    case 'soundfonts':
      return <SoundfontLibrary />;
    case 'liveset':
      return <LiveSetEdit />;
    case 'settings':
      return <Settings />;
    default:
      return <Mixer />;
  }
}

function AppContent() {
  const { currentScreen } = useApp();

  return (
    <div className="min-h-screen bg-black">
      <div className={`${currentScreen === 'settings' ? '' : 'pb-20'} h-screen`}>
        <MainContent />
      </div>
      {currentScreen !== 'settings' && <Navigation />}
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
