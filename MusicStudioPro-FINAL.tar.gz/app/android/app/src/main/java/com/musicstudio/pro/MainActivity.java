package com.musicstudio.pro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
